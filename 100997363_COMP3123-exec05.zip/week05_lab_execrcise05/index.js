const express = require('express');
const app = express();
const router = express.Router();

const path = require('path');
const fs = require('fs'); // Declare fs here once

/*
- Create new html file name home.html 
- add <h1> tag with message "Welcome to ExpressJs Tutorial"
- Return home.html page to client
*/

// Assuming 'home.html' is in the same directory as your Express application
const homeFilePath = path.join(__dirname, 'home.html');

//http://localhost:8089/home
router.get('/home', (req, res) => {
  // Send the 'home.html' file as the response
  res.sendFile(homeFilePath);
});


/*
- Return all details from user.json file to client as JSON format
*/

//http://localhost:8089/profile
app.get('/profile', (req, res) => {
  // Read the user data from 'user.json'
  fs.readFile('user.json', 'utf8', (err, data) => {
    if (err) {
      res.status(500).json({ status: false, message: 'Internal Server Error' });
      return;
    }

    const userData = JSON.parse(data);
    res.json(userData); // Send the user data as JSON
  });
});


/*
- Modify /login router to accept username and password as query string parameter
- Read data from user.json file
- If username and  passsword is valid then send resonse as below 
    {
        status: true,
        message: "User Is valid"
    }
- If username is invalid then send response as below 
    {
        status: false,
        message: "User Name is invalid"
    }
- If passsword is invalid then send response as below 
    {
        status: false,
        message: "Password is invalid"
    }
*/


app.get('/login', (req, res) => {
  const { username, password } = req.query;

  // Read the user data from 'user.json'
  fs.readFile('user.json', 'utf8', (err, data) => {
    if (err) {
      res.status(500).json({ status: false, message: 'Internal Server Error' });
      return;
    }

    const userData = JSON.parse(data);
    const user = userData.find((u) => u.username === username);

    if (!user) {
      res.json({ status: false, message: 'User Name is invalid' });
      return;
    }

    if (user.password === password) {
      res.json({ status: true, message: 'User Is valid' });
    } else {
      res.json({ status: false, message: 'Password is invalid' });
    }
  });
});

/*
- Modify /logout route to accept username as parameter and display message
    in HTML format like <b>${username} successfully logout.<b>
*/
app.get('/logout/:username', (req, res) => {
  const { username } = req.params;

  // Create an HTML response with the username
  const htmlResponse = `<b>${username} successfully logout.<b>`;

  // Send the HTML response to the client
  res.send(htmlResponse);
});
;

app.use('/', router);

app.listen(process.env.port || 8089);

console.log('Web Server is listening at port '+ (process.env.port || 8089));